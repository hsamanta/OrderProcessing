﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OrderProcessing.DataAccess
{
    public class PaymentGateway : IPaymentGateway
    {
        public bool ChargePayment(string creditCardNumber, decimal amount)
        {
            //Assume Charge Payment was sucesfull
            Console.WriteLine("Payment Was Sucesfull");
            return true;
        }
    }
}
