﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;

namespace OrderProcessing.DataAccess
{
    public class EmailService 
    {
        private IEmailClient emailClient;

        public EmailService(IEmailClient client)
        {
            emailClient = client;
        }
        public void SendShippingEmail(string productId)
        {
            var Message = new MailMessage("sell@test.com", "customer@test.com", "Shipping Confirmation", "Please ship the product :" + productId);
            Console.WriteLine("Shipment Notification email sent sucesfully");
            emailClient.Send(Message);
        }
    }
}
