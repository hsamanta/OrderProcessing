﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OrderProcessing.Interfaces;

namespace OrderProcessing.DataAccess
{
    /// <summary>
    /// Mock Service to validate the given Credit card info
    /// For Real Scenario, it will be third party service call
    /// </summary>
    public class MockCreditCardService : IMockCreditCardService
    {
        public bool ValidateCreditCard(string creditCardNo)
        {
            // Assuming Credit card is valid and return true from service
            Console.WriteLine("Given Credit Card card Number is valid : " + creditCardNo);
            return true;
        }
    }
}
