﻿using System.Net.Mail;


namespace OrderProcessing.DataAccess
{
    public class EmailClient : IEmailClient
    {
        public void Send(MailMessage message)
        {
            SmtpClient client = new SmtpClient();
            //Configure Smtp client as needed
            //Below is just a dump configuration
            client.Host = "gmail.com";
            client.Port = 547;
            client.Send(message);
        }
    }
}
