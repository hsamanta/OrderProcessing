﻿using System;
using OrderProcessing.Interfaces;

namespace OrderProcessing.DataAccess
{
    public class ProcessPaymentDataAccess : IProcessPaymentDataAccess
    {
        private IEmailClient emailClient;
        private IPaymentGateway paymentGateway;

        private IMockCreditCardService cdService;

        public ProcessPaymentDataAccess(IEmailClient email, IPaymentGateway payment)
        {
            emailClient = email;
            paymentGateway = payment;
        }
        public bool ProcessCustomerPayment(string CreditCardNumber, decimal amount, IMockCreditCardService creditService)
        {
            cdService = creditService;
            bool isProcessSucesfull = false;
            bool isPaymentSucessfull = false;
            //Assume this is calling a 3rd party service to validate the card.
            bool isCreditCardValid = cdService.ValidateCreditCard(CreditCardNumber);
            if (isCreditCardValid)
            {
                isPaymentSucessfull = paymentGateway.ChargePayment(CreditCardNumber, amount);
            }
            else
            {
                throw new Exception("Credit card is not valid");
            }
            
            if (isPaymentSucessfull)
            {
                var emailservice = new EmailService(emailClient);
                emailservice.SendShippingEmail("productA");
                isProcessSucesfull = true;
            }
            else
            {
                throw new Exception("Payment was sucesfull but notify shipping failed");
            }

            return isProcessSucesfull;
           
        }
    }
}
