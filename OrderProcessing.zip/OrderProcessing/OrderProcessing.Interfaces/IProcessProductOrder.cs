﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OrderProcessing.Interfaces
{
    public interface IProcessProductOrder
    {
       bool ProcessOrder(string productId, int qty, string creditCardNumber);
    }
}
