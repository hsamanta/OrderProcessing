﻿using System;
using OrderProcessing.Interfaces;
using OrderProcessing.BAL;

namespace OrderProcessingApp
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter Product Id..");
            string productid = Console.ReadLine();
            Console.WriteLine("Enter quantity..");
            int qty = 0;
            int.TryParse(Console.ReadLine(), out qty);
            Console.WriteLine("Enter Credit Card Number..");
            string creditCard = Console.ReadLine();
            ProcessOrder(productid, qty, creditCard);
            Console.ReadLine();
        }

        static void ProcessOrder(string prodId, int qty, string creditcard)
        {
            //In Real scenario, the dependent object will be injected from DI container 
            //No need to manually pass dependent object for real scneario
            IProductInventory inventory = new ProductInventory();
            IProcessPayment processPayment = new ProcessPayment();

            IProcessProductOrder processProductOrder = new ProcessProductOrder(inventory, processPayment);

            processProductOrder.ProcessOrder(prodId, qty, creditcard);
        }
    }
}
