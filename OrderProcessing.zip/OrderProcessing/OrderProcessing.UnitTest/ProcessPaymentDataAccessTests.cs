﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OrderProcessing.DataAccess;
using Moq;
using System.Net.Mail;
using OrderProcessing.Interfaces;

namespace OrderProcessing.UnitTest
{
    [TestClass]
    public class ProcessPaymentDataAccessTests
    {
        private Mock<IEmailClient> emailClient;
        private Mock<IPaymentGateway> paymentGateWay;
        private Mock<IMockCreditCardService> crediCardService;

        private IProcessPaymentDataAccess processPaymentDataAccess;

        [TestInitialize]
        public void TestInit()
        {
            emailClient = new Mock<IEmailClient>();
            paymentGateWay = new Mock<IPaymentGateway>();
            crediCardService = new Mock<IMockCreditCardService>();

        }

        [TestMethod]
        public void ProcessPaymentDataAccess_ProcessCustomerPayment_ErrorWhenInvalidCreditCardGiven()
        {
            string creditCard = "Invalid Card";
            decimal amount = 300.5M;
            crediCardService.Setup(x => x.ValidateCreditCard(It.IsAny<string>())).Returns(false);
            processPaymentDataAccess = new ProcessPaymentDataAccess(emailClient.Object, paymentGateWay.Object);

            string expectedResult = "Credit card is not valid";

            var ex = Assert.ThrowsException<Exception>(() => processPaymentDataAccess.ProcessCustomerPayment(creditCard, amount, crediCardService.Object));

            Assert.AreEqual(expectedResult, ex.Message);
        }

        [TestMethod]
        public void ProcessPaymentDataAccess_ProcessCustomerPayment_ValidateEmailSentWhenPaymentIsSucesfull()
        {
            string creditCard = "2141948903248092";
            decimal amount = 300.5M;
            crediCardService.Setup(x => x.ValidateCreditCard(It.IsAny<string>())).Returns(true);
            paymentGateWay.Setup(x => x.ChargePayment(creditCard, amount)).Returns(true);
            emailClient.Setup(x => x.Send(It.IsAny<MailMessage>())).Verifiable();
            processPaymentDataAccess = new ProcessPaymentDataAccess(emailClient.Object, paymentGateWay.Object);

            processPaymentDataAccess.ProcessCustomerPayment(creditCard, amount, crediCardService.Object);

            emailClient.Verify(x => x.Send(It.IsAny<MailMessage>()));
        }
        [TestMethod]
        public void ProcessPaymentDataAccess_ProcessCustomerPayment_ValidateShippentIsNotSentWhenPaymentIsNotSucesfull()
        {
            string creditCard = "2141948903248092";
            decimal amount = 300.5M;
            crediCardService.Setup(x => x.ValidateCreditCard(It.IsAny<string>())).Returns(true);
            paymentGateWay.Setup(x => x.ChargePayment(creditCard, amount)).Returns(false);
            processPaymentDataAccess = new ProcessPaymentDataAccess(emailClient.Object, paymentGateWay.Object);

            string expectedResult = "Payment was sucesfull but notify shipping failed";

            var ex = Assert.ThrowsException<Exception>(() => processPaymentDataAccess.ProcessCustomerPayment(creditCard, amount, crediCardService.Object));

            Assert.AreEqual(expectedResult, ex.Message);
        }

    }
}
