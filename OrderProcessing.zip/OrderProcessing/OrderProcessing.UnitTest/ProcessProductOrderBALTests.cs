﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OrderProcessing.BAL;
using Moq;
using System.Net.Mail;
using OrderProcessing.Interfaces;

namespace OrderProcessing.UnitTest
{
    [TestClass]
    public class ProcessProductOrderBALTests
    {

        private Mock<IProductInventory> productInventory;
        private Mock<IProcessPayment> processPayment;
        private IProcessProductOrder processProductOrder;

        [TestInitialize]
        public void TestInit()
        {
            productInventory = new Mock<IProductInventory>();
            processPayment = new Mock<IProcessPayment>();

        }

        [TestMethod]
        public void ProcessProductOrder_ProcessOrder_ErrorWhenProductIdNotGiven()
        {
            string productId = null;
            int qty = 2;
            string creditcard = "2433345435454345";
            processProductOrder = new ProcessProductOrder(productInventory.Object, processPayment.Object);

            string expectedResult = "Product provide valid product to process order";

            var ex = Assert.ThrowsException<Exception>(() => processProductOrder.ProcessOrder(productId, qty, creditcard));


            Assert.AreEqual(expectedResult, ex.Message);

        }
        [TestMethod]
        public void ProcessProductOrder_ProcessOrder_ErrorWhenQtyIdNotGiven()
        {
            string productId = "12345";
            int qty = 0;
            string creditcard = "2433345435454345";
            processProductOrder = new ProcessProductOrder(productInventory.Object, processPayment.Object);

            string expectedResult = "Product quantity must be greater than zero";

            var ex = Assert.ThrowsException<Exception>(() => processProductOrder.ProcessOrder(productId, qty, creditcard));

            Assert.AreEqual(expectedResult, ex.Message);
        }
        [TestMethod]
        public void ProcessProductOrder_ProcessOrder_ErrorWhenCreditIdNotGiven()
        {
            string productId = "123456";
            int qty = 2;
            string creditcard = null;
            processProductOrder = new ProcessProductOrder(productInventory.Object, processPayment.Object);

            string expectedResult = "Credit Card Number must be provided";

            var ex = Assert.ThrowsException<Exception>(() => processProductOrder.ProcessOrder(productId, qty, creditcard));

            Assert.AreEqual(expectedResult, ex.Message);
        }

        [TestMethod]
        public void ProcessProductOrder_ProcessOrder_ErrorWhenProductIsNotAvailable()
        {
            string productId = "123456";
            int qty = 2;
            string creditcard = "2433345435454345";
            productInventory.Setup(x => x.CheckInventory(productId, qty)).Returns(false);

            processProductOrder = new ProcessProductOrder(productInventory.Object, processPayment.Object);

            string expectedResult = "Given product quantity is not available";
            var ex = Assert.ThrowsException<Exception>(() => processProductOrder.ProcessOrder(productId, qty, creditcard));

            Assert.AreEqual(expectedResult, ex.Message);
        }

        [TestMethod]
        public void ProcessProductOrder_ProcessOrder_ProcessPaymentIsCalledWhenProductAvailable()
        {
            string productId = "123456";
            decimal price = 2.9M;
            int qty = 2;
            string creditcard = "2433345435454345";
            productInventory.Setup(x => x.CheckInventory(productId, qty)).Returns(true);
            processPayment.Setup(x => x.ProcessPayment(creditcard, price)).Verifiable();

            processProductOrder = new ProcessProductOrder(productInventory.Object, processPayment.Object);

            processProductOrder.ProcessOrder(productId, qty, creditcard);

            processPayment.Verify(x => x.ProcessPayment(It.IsAny<string>(), It.IsAny<decimal>()));
        }
    }
}
