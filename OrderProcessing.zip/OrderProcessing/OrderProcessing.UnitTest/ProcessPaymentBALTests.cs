﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OrderProcessing.DataAccess;
using Moq;
using System.Net.Mail;
using OrderProcessing.BAL;
using OrderProcessing.Interfaces;

namespace OrderProcessing.UnitTest
{
    [TestClass]
    public class ProcessPaymentBALTests
    {
        private IProcessPayment processPayment;

        [TestMethod]
        public void ProcessPaymentBAL_ProcessPayment_ShouldReturnTrue()
        {
            string creditCardNumber = "2433345435454345";
            decimal amt = 300.3M;
            var mockPaymentDataAccess = new Mock<IProcessPaymentDataAccess>();
            var mockCrediCardService = new Mock<IMockCreditCardService>();
            mockPaymentDataAccess.Setup(x => x.ProcessCustomerPayment(creditCardNumber, amt, mockCrediCardService.Object)).Returns(true);
            processPayment = new ProcessPayment();

            bool actual = processPayment.ProcessPayment(creditCardNumber, amt);

            Assert.IsTrue(actual);
        }
    }
}
