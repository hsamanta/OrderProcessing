﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OrderProcessing.DataAccess;
using Moq;
using System.Net.Mail;
using OrderProcessing.BAL;
using OrderProcessing.Interfaces;

namespace OrderProcessing.UnitTest
{
    [TestClass]
    public class ProductInventoryBALTests
    {
        private IProductInventory productInventory;
        private string productID;

        [TestInitialize]
        public void TestInit()
        {
            productInventory = new ProductInventory();
            productID = "12345";
        }

        [TestMethod]
        public void ProductInventoryBAL_CheckInventory_ShouldReturnFalseWhenQtyMorethanTwo()
        {
            int qty = 3;
            bool actualResult = productInventory.CheckInventory(productID, qty);
            Assert.IsFalse(actualResult);
        }
        [TestMethod]
        public void ProductInventoryBAL_CheckInventory_ShouldReturnTrueWhenQtyLessthanTwo()
        {
            int qty = 1;
            bool actualResult = productInventory.CheckInventory(productID, qty);
            Assert.IsTrue(actualResult);
        }
        [TestMethod]
        public void ProductInventoryBAL_CheckInventory_ShouldReturnTrueWhenQtyEqualTwo()
        {
            int qty = 2;
            bool actualResult = productInventory.CheckInventory(productID, qty);
            Assert.IsTrue(actualResult);
        }
    }
}
