﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OrderProcessing.DataAccess;
using Moq;
using System.Net.Mail;

namespace OrderProcessing.UnitTest
{
    [TestClass]
    public class EMailServiceTests
    {
        [TestMethod]
        public void EmailService_SendShippingEmail_ShouldSendEmail()
        {
            //Arrange
            string product = "TestProduct";           
            var emailMock = new Mock<IEmailClient>();
            emailMock.Setup(x => x.Send(It.IsAny<MailMessage>())).Verifiable();

            //Act
            var emailService = new EmailService(emailMock.Object);
            emailService.SendShippingEmail(product);

            //Verify
            emailMock.Verify(x => x.Send(It.IsAny<MailMessage>()));

        }
    }
}
