﻿using System;
using OrderProcessing.Interfaces;

namespace OrderProcessing.BAL
{
    public class ProcessProductOrder : IProcessProductOrder
    {
        IProductInventory productInventory;
        IProcessPayment processPayment;
        public ProcessProductOrder(IProductInventory invetory, IProcessPayment processPay)
        {
            productInventory = invetory;
            processPayment = processPay;
        }
        public bool ProcessOrder(string productId, int qty, string creditCardNumber)
        {
            if (string.IsNullOrEmpty(productId))
            {
                throw new Exception("Product provide valid product to process order");
            }
            if (qty <= 0)
            {
                throw new Exception("Product quantity must be greater than zero");
            }
            if (string.IsNullOrEmpty(creditCardNumber))
            {
                throw new Exception("Credit Card Number must be provided");
            }
            try
            {

                //check inventroy first if product is available 
                bool isProductAvailable = productInventory.CheckInventory(productId, qty);

                if (isProductAvailable)
                {
                    //Assume each product proce is 100.5
                    decimal productPrice = Convert.ToDecimal(qty * 100.5);
                    processPayment.ProcessPayment(creditCardNumber, productPrice);
                }
                else
                {
                    throw new Exception("Given product quantity is not available");
                }
            }
            catch(Exception ex)
            {
                //Log the exception in exection logger 
                //Handler Exception as per business requirement 
                //For noe throw to root level
                Console.WriteLine(ex.Message);
            }

            return true;
        }
    }
}
