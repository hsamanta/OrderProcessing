﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OrderProcessing.Interfaces;

namespace OrderProcessing.BAL
{
    public class ProductInventory : IProductInventory
    {
        public bool CheckInventory(string productId, int qty)
        {
            //For now assume if qty is less than 2, then it is available and if it is more than 2 then not available
            return qty <= 2 ? true : false;
        }
    }
}
