﻿using System;
using OrderProcessing.DataAccess;
using OrderProcessing.Interfaces;

namespace OrderProcessing.BAL
{
    public class ProcessPayment : IProcessPayment
    {
        private IProcessPaymentDataAccess processPaymentDA;
        private IEmailClient emailClient;
        private IPaymentGateway paymentGatWay;

        public ProcessPayment()
        {
            emailClient = new EmailClient();
            paymentGatWay = new PaymentGateway();
            processPaymentDA = new ProcessPaymentDataAccess(emailClient,paymentGatWay);
        }

        bool IProcessPayment.ProcessPayment(string CreditCardNumber, decimal amount)
        {
          return processPaymentDA.ProcessCustomerPayment(CreditCardNumber, amount, new MockCreditCardService());
        }
    }
}
